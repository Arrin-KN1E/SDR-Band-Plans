window.onload=function(){document.getElementById("n-randompage").innerHTML="<a href='/wiki/Special:Random?"+Math.floor((Math.random()*314141414144444444032323))+"'>Random page</a>";}
console.log("test");;mw.loader.state({"site":"ready"});
/* cache key: fish_sigidwiki-mwiki_:resourceloader:filter:minify-js:7:77acf9dfcfe797ed3d0d73c3a4f358fe */